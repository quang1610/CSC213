//
// Created by Nguyễn Đức Quang on 5/7/20.
//

#ifndef CSC213_GET_IP_H
#define CSC213_GET_IP_H

#endif //CSC213_GET_IP_H

char *get_ip();