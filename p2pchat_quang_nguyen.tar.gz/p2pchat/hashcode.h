//
// Created by Nguyễn Đức Quang on 5/6/20.
//

#ifndef CSC213_HASHCODE_H
#define CSC213_HASHCODE_H

#endif //CSC213_HASHCODE_H

unsigned long hashcode(const char *str);